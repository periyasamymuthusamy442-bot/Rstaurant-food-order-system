# ============================================================
# FOODHUB - APP.PY
# Flask + MongoDB
# ============================================================

import os
import re
from functools import wraps
from datetime import datetime, timezone

from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    session,
    redirect,
    url_for
)

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

from werkzeug.utils import secure_filename

from bson.objectid import ObjectId
from bson.errors import InvalidId

import pymongo.errors

from config import Config
from db import get_db


# ============================================================
# APP CONFIG
# ============================================================

app = Flask(__name__)
app.config.from_object(Config)

# Secret key
if not app.secret_key:
    app.secret_key = os.environ.get(
        "SECRET_KEY",
        "foodhub-development-secret-key"
    )


# ============================================================
# CONSTANTS
# ============================================================

ORDER_STATUS_FLOW = [
    "Preparing",
    "Out for Delivery",
    "Delivered"
]


# ============================================================
# DATABASE SETUP
# ============================================================

def ensure_setup():

    try:
        db = get_db()

        # ----------------------------------------------------
        # USER INDEX
        # ----------------------------------------------------

        try:
            db.users.create_index(
                "email",
                unique=True
            )
        except pymongo.errors.DuplicateKeyError:
            pass

        # ----------------------------------------------------
        # ADMIN INDEX
        # ----------------------------------------------------

        try:
            db.admins.create_index(
                "username",
                unique=True
            )
        except pymongo.errors.DuplicateKeyError:
            pass

        # ----------------------------------------------------
        # DEFAULT ADMIN
        # ----------------------------------------------------

        admin = db.admins.find_one({
            "username": "admin"
        })

        if not admin:

            db.admins.insert_one({
                "username": "admin",
                "password_hash": generate_password_hash(
                    "admin123"
                ),
                "created_at": datetime.now(timezone.utc)
            })

            print("================================")
            print("Default admin created")
            print("Username : admin")
            print("Password : admin123")
            print("================================")

        # ----------------------------------------------------
        # DEFAULT FOODS
        # ----------------------------------------------------

        if db.foods.count_documents({}) == 0:

            now = datetime.now(timezone.utc)

            foods = [

                {
                    "name": "Cheese Pizza",
                    "category": "Pizza",
                    "price": 249.0,
                    "rating": 4.8,
                    "description":
                        "Loaded with mozzarella cheese and herbs.",
                    "image": "images/Pizza.jpg",
                    "created_at": now
                },

                {
                    "name": "Chicken Burger",
                    "category": "Burger",
                    "price": 149.0,
                    "rating": 4.7,
                    "description":
                        "Juicy grilled chicken burger.",
                    "image": "images/Burger.jpg",
                    "created_at": now
                },

                {
                    "name": "Chicken Biryani",
                    "category": "Biryani",
                    "price": 299.0,
                    "rating": 4.9,
                    "description":
                        "Aromatic basmati rice with chicken.",
                    "image": "images/Biryani.jpg",
                    "created_at": now
                },

                {
                    "name": "Masala Dosa",
                    "category": "Dosa",
                    "price": 99.0,
                    "rating": 4.6,
                    "description":
                        "Crispy dosa with potato masala.",
                    "image": "images/Dosa.jpg",
                    "created_at": now
                },

                {
                    "name": "Orange Juice",
                    "category": "Juice",
                    "price": 79.0,
                    "rating": 4.5,
                    "description":
                        "Fresh orange juice.",
                    "image": "images/Juice.jpg",
                    "created_at": now
                },

                {
                    "name": "Vanilla Ice Cream",
                    "category": "Ice Cream",
                    "price": 129.0,
                    "rating": 4.9,
                    "description":
                        "Creamy vanilla ice cream.",
                    "image": "images/Ice Cream.jpg",
                    "created_at": now
                }
            ]

            db.foods.insert_many(foods)

            print("Default foods added.")

    except pymongo.errors.ServerSelectionTimeoutError as error:

        print("MongoDB connection failed.")
        print(error)

    except pymongo.errors.ConnectionFailure as error:

        print("MongoDB connection failure.")
        print(error)

    except Exception as error:

        print("Database setup error:")
        print(error)


# ============================================================
# RUN DATABASE SETUP
# ============================================================

with app.app_context():
    ensure_setup()


# ============================================================
# HELPERS
# ============================================================

def login_required(function):

    @wraps(function)
    def wrapper(*args, **kwargs):

        if "user_id" not in session:

            return jsonify({
                "success": False,
                "message": "Please login first."
            }), 401

        return function(*args, **kwargs)

    return wrapper


def admin_required(function):

    @wraps(function)
    def wrapper(*args, **kwargs):

        if "admin_id" not in session:

            return jsonify({
                "success": False,
                "message": "Admin login required."
            }), 401

        return function(*args, **kwargs)

    return wrapper


def oid(value):

    if value is None:
        return None

    try:

        return ObjectId(str(value))

    except (
        InvalidId,
        TypeError,
        ValueError
    ):

        return None


def allowed_file(filename):

    if not filename:
        return False

    if "." not in filename:
        return False

    extension = filename.rsplit(
        ".",
        1
    )[1].lower()

    allowed = getattr(
        Config,
        "ALLOWED_EXTENSIONS",
        {
            "png",
            "jpg",
            "jpeg",
            "gif",
            "webp"
        }
    )

    return extension in allowed


def food_image_url(image_path):

    if not image_path:
        return None

    image_path = str(image_path)

    if image_path.startswith("http://"):
        return image_path

    if image_path.startswith("https://"):
        return image_path

    image_path = image_path.lstrip("/")

    return url_for(
        "static",
        filename=image_path
    )


def serialize_food(food):

    price = food.get(
        "price",
        0
    )

    rating = food.get(
        "rating",
        4.5
    )

    try:
        price = float(price)
    except (
        ValueError,
        TypeError
    ):
        price = 0.0

    try:
        rating = float(rating)
    except (
        ValueError,
        TypeError
    ):
        rating = 4.5

    return {

        "id": str(
            food["_id"]
        ),

        "name": food.get(
            "name",
            ""
        ),

        "category": food.get(
            "category",
            ""
        ),

        "price": price,

        "rating": rating,

        "description": food.get(
            "description",
            ""
        ),

        "image": food.get(
            "image"
        ),

        "image_url": food_image_url(
            food.get("image")
        )
    }


def serialize_order(order):

    items = []

    for item in order.get(
        "items",
        []
    ):

        price = item.get(
            "price",
            0
        )

        quantity = item.get(
            "quantity",
            1
        )

        try:
            price = float(price)
        except (
            ValueError,
            TypeError
        ):
            price = 0.0

        try:
            quantity = int(quantity)
        except (
            ValueError,
            TypeError
        ):
            quantity = 1

        if quantity < 1:
            quantity = 1

        image = item.get(
            "image"
        )

        items.append({

            "food_id": str(
                item.get(
                    "food_id",
                    ""
                )
            ),

            "name": item.get(
                "name",
                "Food Item"
            ),

            "price": price,

            "quantity": quantity,

            "image": image,

            "image_url": food_image_url(
                image
            )
        })

    created_at = order.get(
        "created_at"
    )

    if created_at:

        try:

            created_at = created_at.strftime(
                "%Y-%m-%d %H:%M"
            )

        except AttributeError:

            created_at = str(
                created_at
            )

    return {

        "id": str(
            order["_id"]
        ),

        "user_id": str(
            order.get(
                "user_id",
                ""
            )
        ),

        "items": items,

        "item_total": float(
            order.get(
                "item_total",
                0
            )
        ),

        "gst": float(
            order.get(
                "gst",
                0
            )
        ),

        "delivery_charge": float(
            order.get(
                "delivery_charge",
                0
            )
        ),

        "grand_total": float(
            order.get(
                "grand_total",
                0
            )
        ),

        "payment_method": order.get(
            "payment_method",
            "Cash On Delivery"
        ),

        "status": order.get(
            "status",
            "Preparing"
        ),

        "created_at": created_at
    }


def get_request_data():

    json_data = request.get_json(
        silent=True
    )

    if json_data:
        return json_data

    return request.form


def save_uploaded_image(file):

    if not file:
        return None

    if not file.filename:
        return None

    if not allowed_file(
        file.filename
    ):
        return None

    upload_folder = getattr(
        Config,
        "UPLOAD_FOLDER",
        "uploads"
    )

    upload_dir = os.path.join(
        app.static_folder,
        upload_folder
    )

    os.makedirs(
        upload_dir,
        exist_ok=True
    )

    filename = secure_filename(
        file.filename
    )

    if not filename:
        return None

    base, extension = os.path.splitext(
        filename
    )

    final_name = filename
    counter = 1

    while os.path.exists(
        os.path.join(
            upload_dir,
            final_name
        )
    ):

        final_name = (
            f"{base}_{counter}{extension}"
        )

        counter += 1

    file.save(
        os.path.join(
            upload_dir,
            final_name
        )
    )

    return (
        f"{upload_folder}/{final_name}"
    ).replace(
        "\\",
        "/"
    )


# ============================================================
# PAGE ROUTES
# ============================================================

@app.route("/")
def index():

    if "user_id" in session:

        return redirect(
            url_for("home_page")
        )

    return redirect(
        url_for("login_page")
    )


@app.route("/home.html")
def home_page():

    return render_template(
        "home.html"
    )


@app.route("/menu.html")
def menu_page():

    return render_template(
        "menu.html"
    )


# ============================================================
# RESTAURANTS PAGE
# FIX FOR:
# BuildError: restaurants_page
# ============================================================

@app.route("/restaurants.html")
def restaurants_page():

    # If restaurants.html exists,
    # use it automatically.
    template_folder = app.template_folder or "templates"

    restaurants_template = os.path.join(
        app.root_path,
        template_folder,
        "restaurants.html"
    )

    if os.path.exists(restaurants_template):

        return render_template(
            "restaurants.html"
        )

    # If restaurants.html doesn't exist,
    # open menu page instead.
    return render_template(
        "menu.html"
    )


@app.route("/cart.html")
def cart_page():

    return render_template(
        "cart.html"
    )


@app.route("/orders.html")
def orders_page():

    return render_template(
        "orders.html"
    )


# ============================================================
# CUSTOMER PROFILE
# ============================================================

@app.route("/profile.html")
def profile_page():

    if "user_id" not in session:

        return redirect(
            url_for("login_page")
        )

    return render_template(
        "profile.html"
    )


# ============================================================
# HELP & SUPPORT
# ============================================================

@app.route("/help.html")
def help_page():

    return render_template(
        "help.html"
    )


@app.route("/contact.html")
def contact_page():

    return render_template(
        "contact.html"
    )


@app.route("/offers.html")
def offers_page():

    return render_template(
        "offers.html"
    )


@app.route("/login.html")
def login_page():

    return render_template(
        "login.html"
    )


@app.route("/register.html")
def register_page():

    return render_template(
        "register.html"
    )


@app.route("/payment.html")
def payment_page():

    return render_template(
        "payment.html"
    )


@app.route("/success.html")
def success_page():

    return render_template(
        "success.html"
    )


# ============================================================
# ADMIN PAGE ROUTES
# ============================================================

@app.route("/admin_login.html")
def admin_login_page():

    return render_template(
        "admin_login.html"
    )


@app.route("/admin_dashboard.html")
def admin_dashboard_page():

    return render_template(
        "admin_dashboard.html"
    )


@app.route("/add_food.html")
def add_food_page():

    return render_template(
        "add_food.html"
    )


@app.route("/edit_food.html")
def edit_food_page():

    return render_template(
        "edit_food.html"
    )


@app.route("/view_orders.html")
def view_orders_page():

    return render_template(
        "view_orders.html"
    )


# ============================================================
# CUSTOMER REGISTER
# ============================================================

@app.route(
    "/api/register",
    methods=["POST"]
)
def api_register():

    data = get_request_data()

    name = str(
        data.get("name") or ""
    ).strip()

    email = str(
        data.get("email") or ""
    ).strip().lower()

    mobile = str(
        data.get("mobile") or ""
    ).strip()

    password = str(
        data.get("password") or ""
    )

    if not all([
        name,
        email,
        mobile,
        password
    ]):

        return jsonify({
            "success": False,
            "message": "Please fill all fields."
        }), 400

    if (
        len(mobile) != 10
        or not mobile.isdigit()
    ):

        return jsonify({
            "success": False,
            "message":
                "Enter valid 10-digit mobile number."
        }), 400

    if len(password) < 6:

        return jsonify({
            "success": False,
            "message":
                "Password must be at least 6 characters."
        }), 400

    db = get_db()

    existing_user = db.users.find_one({
        "email": email
    })

    if existing_user:

        return jsonify({
            "success": False,
            "message":
                "Email already exists."
        }), 409

    try:

        result = db.users.insert_one({

            "name": name,

            "email": email,

            "mobile": mobile,

            "password_hash":
                generate_password_hash(
                    password
                ),

            "created_at":
                datetime.now(timezone.utc)
        })

    except pymongo.errors.DuplicateKeyError:

        return jsonify({
            "success": False,
            "message":
                "Email already exists."
        }), 409

    return jsonify({

        "success": True,

        "message":
            "Registration successful!",

        "user_id":
            str(
                result.inserted_id
            )
    })


# ============================================================
# CUSTOMER LOGIN
# ============================================================

@app.route(
    "/api/login",
    methods=["POST"]
)
def api_login():

    data = get_request_data()

    email = str(
        data.get("email") or ""
    ).strip().lower()

    password = str(
        data.get("password") or ""
    )

    if not email or not password:

        return jsonify({
            "success": False,
            "message":
                "Please enter email and password."
        }), 400

    db = get_db()

    user = db.users.find_one({
        "email": email
    })

    if not user:

        return jsonify({
            "success": False,
            "message":
                "Invalid email or password."
        }), 401

    password_hash = user.get(
        "password_hash"
    )

    if not password_hash:

        return jsonify({
            "success": False,
            "message":
                "Password data is missing for this user."
        }), 500

    try:

        valid_password = check_password_hash(
            password_hash,
            password
        )

    except Exception:

        valid_password = False

    if not valid_password:

        return jsonify({
            "success": False,
            "message":
                "Invalid email or password."
        }), 401

    session.clear()

    session["user_id"] = str(
        user["_id"]
    )

    session["user_name"] = user.get(
        "name",
        ""
    )

    session["user_email"] = user.get(
        "email",
        email
    )

    return jsonify({

        "success": True,

        "message":
            "Login successful!",

        "user": {

            "id": str(
                user["_id"]
            ),

            "name": user.get(
                "name",
                ""
            ),

            "email": user.get(
                "email",
                email
            )
        }
    })


# ============================================================
# CUSTOMER LOGOUT
# ============================================================

@app.route(
    "/api/logout",
    methods=["POST"]
)
def api_logout():

    session.clear()

    return jsonify({

        "success": True,

        "message":
            "Logged out successfully."
    })


# ============================================================
# CUSTOMER SESSION
# ============================================================

@app.route(
    "/api/session",
    methods=["GET"]
)
def api_session():

    user_id = session.get(
        "user_id"
    )

    if user_id:

        return jsonify({

            "logged_in": True,

            "name": session.get(
                "user_name",
                "User"
            ),

            "email": session.get(
                "user_email",
                ""
            ),

            "user_id": user_id
        })

    return jsonify({
        "logged_in": False
    })


# ============================================================
# ADMIN LOGIN
# ============================================================

@app.route(
    "/api/admin/login",
    methods=["POST"]
)
def api_admin_login():

    data = get_request_data()

    username = str(
        data.get("username") or ""
    ).strip()

    password = str(
        data.get("password") or ""
    )

    if not username or not password:

        return jsonify({
            "success": False,
            "message":
                "Please enter username and password."
        }), 400

    db = get_db()

    admin = db.admins.find_one({
        "username": username
    })

    if not admin:

        return jsonify({
            "success": False,
            "message":
                "Invalid Username or Password"
        }), 401

    password_hash = admin.get(
        "password_hash"
    )

    if not password_hash:

        return jsonify({
            "success": False,
            "message":
                "Admin password data is missing."
        }), 500

    try:

        valid_password = check_password_hash(
            password_hash,
            password
        )

    except Exception:

        valid_password = False

    if not valid_password:

        return jsonify({
            "success": False,
            "message":
                "Invalid Username or Password"
        }), 401

    session.clear()

    session["admin_id"] = str(
        admin["_id"]
    )

    session["admin_username"] = (
        admin.get(
            "username",
            username
        )
    )

    return jsonify({

        "success": True,

        "message":
            "Admin Login Successful"
    })


# ============================================================
# ADMIN LOGOUT
# ============================================================

@app.route(
    "/api/admin/logout",
    methods=["POST"]
)
def api_admin_logout():

    session.pop(
        "admin_id",
        None
    )

    session.pop(
        "admin_username",
        None
    )

    return jsonify({
        "success": True
    })


# ============================================================
# ADMIN SESSION
# ============================================================

@app.route(
    "/api/admin/session",
    methods=["GET"]
)
def api_admin_session():

    if "admin_id" in session:

        return jsonify({

            "logged_in": True,

            "username":
                session.get(
                    "admin_username",
                    ""
                )
        })

    return jsonify({
        "logged_in": False
    })


# ============================================================
# GET ALL FOODS
# ============================================================

@app.route(
    "/api/foods",
    methods=["GET"]
)
def api_foods():

    category = (
        request.args.get(
            "category",
            ""
        ).strip()
    )

    search = (
        request.args.get(
            "search",
            ""
        ).strip()
    )

    db = get_db()

    query = {}

    # --------------------------------------------------------
    # CATEGORY
    # --------------------------------------------------------

    if (
        category
        and category.lower() != "all"
    ):

        query["category"] = {

            "$regex":
                f"^{re.escape(category)}$",

            "$options": "i"
        }

    # --------------------------------------------------------
    # SEARCH
    # --------------------------------------------------------

    if search:

        safe_search = re.escape(
            search
        )

        query["$or"] = [

            {
                "name": {
                    "$regex":
                        safe_search,
                    "$options":
                        "i"
                }
            },

            {
                "category": {
                    "$regex":
                        safe_search,
                    "$options":
                        "i"
                }
            }
        ]

    foods = list(
        db.foods.find(
            query
        ).sort(
            "created_at",
            -1
        )
    )

    return jsonify({

        "success": True,

        "foods": [
            serialize_food(food)
            for food in foods
        ]
    })


# ============================================================
# GET SINGLE FOOD
# ============================================================

@app.route(
    "/api/foods/<food_id>",
    methods=["GET"]
)
def api_food_detail(food_id):

    food_oid = oid(
        food_id
    )

    if not food_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid food ID."
        }), 400

    db = get_db()

    food = db.foods.find_one({
        "_id": food_oid
    })

    if not food:

        return jsonify({
            "success": False,
            "message":
                "Food not found."
        }), 404

    return jsonify({

        "success": True,

        "food":
            serialize_food(food)
    })


# ============================================================
# ADMIN - ADD FOOD
# ============================================================

@app.route(
    "/api/admin/foods",
    methods=["POST"]
)
@admin_required
def api_add_food():

    data = get_request_data()

    name = str(
        data.get("name") or ""
    ).strip()

    category = str(
        data.get("category") or ""
    ).strip()

    price_value = data.get(
        "price"
    )

    description = str(
        data.get("description") or ""
    ).strip()

    if (
        not name
        or not category
        or price_value in (
            None,
            ""
        )
    ):

        return jsonify({
            "success": False,
            "message":
                "Please fill all required fields."
        }), 400

    try:

        price = float(
            price_value
        )

    except (
        ValueError,
        TypeError
    ):

        return jsonify({
            "success": False,
            "message":
                "Invalid price."
        }), 400

    if price < 0:

        return jsonify({
            "success": False,
            "message":
                "Price cannot be negative."
        }), 400

    image_rel_path = None

    file = request.files.get(
        "image"
    )

    if file and file.filename:

        if not allowed_file(
            file.filename
        ):

            return jsonify({
                "success": False,
                "message":
                    "Invalid image format."
            }), 400

        image_rel_path = (
            save_uploaded_image(
                file
            )
        )

    db = get_db()

    result = db.foods.insert_one({

        "name": name,

        "category": category,

        "price": price,

        "rating": 4.5,

        "description": description,

        "image": image_rel_path,

        "created_at":
            datetime.now(
                timezone.utc
            )
    })

    return jsonify({

        "success": True,

        "message":
            "Food added successfully!",

        "food_id":
            str(
                result.inserted_id
            )
    })


# ============================================================
# ADMIN - UPDATE FOOD
# ============================================================

@app.route(
    "/api/admin/foods/<food_id>",
    methods=["PUT"]
)
@admin_required
def api_update_food(food_id):

    food_oid = oid(
        food_id
    )

    if not food_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid food ID."
        }), 400

    db = get_db()

    existing = db.foods.find_one({
        "_id": food_oid
    })

    if not existing:

        return jsonify({
            "success": False,
            "message":
                "Food not found."
        }), 404

    data = get_request_data()

    update = {}

    # NAME
    if "name" in data:

        name = str(
            data.get("name") or ""
        ).strip()

        if name:
            update["name"] = name

    # CATEGORY
    if "category" in data:

        category = str(
            data.get("category") or ""
        ).strip()

        if category:
            update["category"] = category

    # PRICE
    if "price" in data:

        try:

            price = float(
                data.get("price")
            )

        except (
            ValueError,
            TypeError
        ):

            return jsonify({
                "success": False,
                "message":
                    "Invalid price."
            }), 400

        if price < 0:

            return jsonify({
                "success": False,
                "message":
                    "Price cannot be negative."
            }), 400

        update["price"] = price

    # RATING
    if "rating" in data:

        try:

            rating = float(
                data.get("rating")
            )

        except (
            ValueError,
            TypeError
        ):

            rating = None

        if rating is not None:

            rating = max(
                0,
                min(
                    5,
                    rating
                )
            )

            update["rating"] = rating

    # DESCRIPTION
    if "description" in data:

        update["description"] = str(
            data.get(
                "description"
            ) or ""
        ).strip()

    # IMAGE
    file = request.files.get(
        "image"
    )

    if file and file.filename:

        if not allowed_file(
            file.filename
        ):

            return jsonify({
                "success": False,
                "message":
                    "Invalid image format."
            }), 400

        image_path = save_uploaded_image(
            file
        )

        if image_path:

            update["image"] = image_path

    if not update:

        return jsonify({
            "success": False,
            "message":
                "No changes provided."
        }), 400

    db.foods.update_one(
        {
            "_id": food_oid
        },
        {
            "$set": update
        }
    )

    return jsonify({

        "success": True,

        "message":
            "Food updated successfully!"
    })


# ============================================================
# ADMIN - DELETE FOOD
# ============================================================

@app.route(
    "/api/admin/foods/<food_id>",
    methods=["DELETE"]
)
@admin_required
def api_delete_food(food_id):

    food_oid = oid(
        food_id
    )

    if not food_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid food ID."
        }), 400

    db = get_db()

    result = db.foods.delete_one({
        "_id": food_oid
    })

    if result.deleted_count == 0:

        return jsonify({
            "success": False,
            "message":
                "Food not found."
        }), 404

    return jsonify({

        "success": True,

        "message":
            "Food deleted successfully!"
    })


# ============================================================
# PLACE ORDER
# ============================================================

@app.route(
    "/api/orders",
    methods=["POST"]
)
@login_required
def api_place_order():

    data = request.get_json(
        silent=True
    ) or {}

    items = data.get(
        "items"
    ) or []

    payment_method = str(
        data.get(
            "payment_method",
            "Cash On Delivery"
        )
    ).strip()

    if not items:

        return jsonify({
            "success": False,
            "message":
                "Your cart is empty."
        }), 400

    db = get_db()

    item_total = 0.0
    order_items = []

    for item in items:

        if not isinstance(
            item,
            dict
        ):
            continue

        food_id = (
            item.get("food_id")
            or item.get("id")
            or item.get("_id")
        )

        food_name = str(
            item.get("name")
            or item.get("food_name")
            or ""
        ).strip()

        try:

            quantity = int(
                item.get(
                    "quantity",
                    1
                )
            )

        except (
            ValueError,
            TypeError
        ):

            quantity = 1

        if quantity < 1:
            quantity = 1

        food = None

        food_oid = oid(
            food_id
        )

        if food_oid:

            food = db.foods.find_one({
                "_id": food_oid
            })

        if (
            not food
            and food_name
        ):

            food = db.foods.find_one({

                "name": {

                    "$regex":
                        "^" +
                        re.escape(
                            food_name
                        ) +
                        "$",

                    "$options":
                        "i"
                }
            })

        if not food:

            return jsonify({
                "success": False,
                "message":
                    "Food item not found. Please refresh the menu and add the food again."
            }), 404

        try:

            food_price = float(
                food.get(
                    "price",
                    0
                )
            )

        except (
            ValueError,
            TypeError
        ):

            food_price = 0.0

        line_total = (
            food_price *
            quantity
        )

        item_total += line_total

        order_items.append({

            "food_id":
                str(
                    food["_id"]
                ),

            "name":
                food.get(
                    "name",
                    "Food Item"
                ),

            "price":
                food_price,

            "quantity":
                quantity,

            "image":
                food.get(
                    "image"
                )
        })

    if not order_items:

        return jsonify({
            "success": False,
            "message":
                "No valid food items found."
        }), 400

    # BILL
    gst = 20.0
    delivery_charge = 40.0

    grand_total = (
        item_total
        + gst
        + delivery_charge
    )

    # USER
    user_oid = oid(
        session.get(
            "user_id"
        )
    )

    if not user_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid user session."
        }), 401

    # SAVE ORDER
    result = db.orders.insert_one({

        "user_id":
            user_oid,

        "items":
            order_items,

        "item_total":
            round(
                item_total,
                2
            ),

        "gst":
            round(
                gst,
                2
            ),

        "delivery_charge":
            round(
                delivery_charge,
                2
            ),

        "grand_total":
            round(
                grand_total,
                2
            ),

        "payment_method":
            payment_method
            or "Cash On Delivery",

        "status":
            "Preparing",

        "created_at":
            datetime.now(
                timezone.utc
            )
    })

    return jsonify({

        "success":
            True,

        "message":
            "Order placed successfully!",

        "order_id":
            str(
                result.inserted_id
            ),

        "grand_total":
            round(
                grand_total,
                2
            )
    })


# ============================================================
# CUSTOMER - MY ORDERS
# ============================================================

@app.route(
    "/api/orders",
    methods=["GET"]
)
@login_required
def api_my_orders():

    user_oid = oid(
        session.get(
            "user_id"
        )
    )

    if not user_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid user session."
        }), 401

    db = get_db()

    orders = list(
        db.orders.find({
            "user_id":
                user_oid
        }).sort(
            "created_at",
            -1
        )
    )

    return jsonify({

        "success": True,

        "orders": [
            serialize_order(order)
            for order in orders
        ]
    })


# ============================================================
# ADMIN - ALL ORDERS
# ============================================================

@app.route(
    "/api/admin/orders",
    methods=["GET"]
)
@admin_required
def api_admin_orders():

    db = get_db()

    orders = list(
        db.orders.find({})
        .sort(
            "created_at",
            -1
        )
    )

    return jsonify({

        "success": True,

        "orders": [
            serialize_order(order)
            for order in orders
        ]
    })


# ============================================================
# ADMIN - UPDATE ORDER STATUS
# ============================================================

@app.route(
    "/api/admin/orders/<order_id>/status",
    methods=["PUT"]
)
@admin_required
def api_update_order_status(
    order_id
):

    order_oid = oid(
        order_id
    )

    if not order_oid:

        return jsonify({
            "success": False,
            "message":
                "Invalid order ID."
        }), 400

    db = get_db()

    order = db.orders.find_one({
        "_id":
            order_oid
    })

    if not order:

        return jsonify({
            "success": False,
            "message":
                "Order not found."
        }), 404

    current_status = order.get(
        "status",
        "Preparing"
    )

    if current_status not in ORDER_STATUS_FLOW:

        next_status = ORDER_STATUS_FLOW[0]

    else:

        current_index = (
            ORDER_STATUS_FLOW.index(
                current_status
            )
        )

        if (
            current_index
            <
            len(ORDER_STATUS_FLOW) - 1
        ):

            next_status = (
                ORDER_STATUS_FLOW[
                    current_index + 1
                ]
            )

        else:

            next_status = (
                ORDER_STATUS_FLOW[-1]
            )

    db.orders.update_one(

        {
            "_id":
                order_oid
        },

        {
            "$set": {

                "status":
                    next_status,

                "updated_at":
                    datetime.now(
                        timezone.utc
                    )
            }
        }
    )

    return jsonify({

        "success": True,

        "status":
            next_status
    })


# ============================================================
# ADMIN DASHBOARD
# ============================================================

@app.route(
    "/api/admin/dashboard",
    methods=["GET"]
)
@admin_required
def api_admin_dashboard():

    db = get_db()

    total_orders = (
        db.orders.count_documents({})
    )

    total_customers = (
        db.users.count_documents({})
    )

    total_foods = (
        db.foods.count_documents({})
    )

    revenue_cursor = (
        db.orders.aggregate([

            {
                "$group": {

                    "_id": None,

                    "total": {

                        "$sum":
                            "$grand_total"
                    }
                }
            }
        ])
    )

    revenue_doc = next(
        revenue_cursor,
        None
    )

    total_revenue = 0.0

    if revenue_doc:

        try:

            total_revenue = float(
                revenue_doc.get(
                    "total",
                    0
                )
            )

        except (
            ValueError,
            TypeError
        ):

            total_revenue = 0.0

    return jsonify({

        "success":
            True,

        "totalOrders":
            total_orders,

        "totalCustomers":
            total_customers,

        "totalFoods":
            total_foods,

        "totalRevenue":
            round(
                total_revenue,
                2
            )
    })


# ============================================================
# CONTACT
# ============================================================

@app.route(
    "/api/contact",
    methods=["POST"]
)
def api_contact():

    data = get_request_data()

    name = str(
        data.get("name") or ""
    ).strip()

    email = str(
        data.get("email") or ""
    ).strip().lower()

    message = str(
        data.get("message") or ""
    ).strip()

    if (
        not name
        or not email
        or not message
    ):

        return jsonify({
            "success": False,
            "message":
                "Please fill all fields."
        }), 400

    db = get_db()

    db.contact_messages.insert_one({

        "name":
            name,

        "email":
            email,

        "message":
            message,

        "created_at":
            datetime.now(
                timezone.utc
            )
    })

    return jsonify({

        "success": True,

        "message":
            "Your message has been sent successfully!"
    })


# ============================================================
# ERROR HANDLERS
# ============================================================

@app.errorhandler(404)
def page_not_found(error):

    if request.path.startswith(
        "/api/"
    ):

        return jsonify({

            "success": False,

            "message":
                "API endpoint not found."
        }), 404

    return render_template(
        "login.html"
    ), 404


@app.errorhandler(500)
def internal_server_error(error):

    print(
        "Internal Server Error:",
        error
    )

    if request.path.startswith(
        "/api/"
    ):

        return jsonify({

            "success": False,

            "message":
                "Internal server error."
        }), 500

    return (
        "Internal Server Error",
        500
    )


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )